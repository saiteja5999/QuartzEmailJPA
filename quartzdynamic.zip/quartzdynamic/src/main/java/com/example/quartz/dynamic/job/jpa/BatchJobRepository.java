package com.example.quartz.dynamic.job.jpa;

import org.springframework.data.repository.CrudRepository;

import com.example.quartz.dynamic.job.model.BatchJob;

public interface BatchJobRepository extends CrudRepository<BatchJob, Long>{
	
	BatchJob findById(long id);

}
